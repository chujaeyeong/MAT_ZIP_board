package com.mat.zip.point.service;

public interface PointExchangeHistoryService {
    void exChange(String userId, int id);
    void useDetailHistory(String userId, int id);
}
