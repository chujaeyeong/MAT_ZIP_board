package com.mat.zip.boss.service;

import java.util.List;

public interface boss_ReviewService {
	List<String> TotalReview(String storeId);
}
