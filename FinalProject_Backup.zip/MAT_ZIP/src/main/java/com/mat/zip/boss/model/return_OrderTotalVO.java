package com.mat.zip.boss.model;

public class return_OrderTotalVO {

	private String store_id;
	private int newOrdersThisMonth;
    private int newOrderTotalThisMonth;
    private int returningOrdersThisMonth;
    private int returningOrderTotalThisMonth;
    private int newOrdersLastMonth;
    private int newOrdersTotalLastMonth;
    private int returningOrdersLastMonth;
    private int returningOrderTotalLastMonth;
	public String getStore_id() {
		return store_id;
	}
	public void setStore_id(String store_id) {
		this.store_id = store_id;
	}
	public int getNewOrdersThisMonth() {
		return newOrdersThisMonth;
	}
	public void setNewOrdersThisMonth(int newOrdersThisMonth) {
		this.newOrdersThisMonth = newOrdersThisMonth;
	}
	public int getNewOrderTotalThisMonth() {
		return newOrderTotalThisMonth;
	}
	public void setNewOrderTotalThisMonth(int newOrderTotalThisMonth) {
		this.newOrderTotalThisMonth = newOrderTotalThisMonth;
	}
	public int getReturningOrdersThisMonth() {
		return returningOrdersThisMonth;
	}
	public void setReturningOrdersThisMonth(int returningOrdersThisMonth) {
		this.returningOrdersThisMonth = returningOrdersThisMonth;
	}
	public int getReturningOrderTotalThisMonth() {
		return returningOrderTotalThisMonth;
	}
	public void setReturningOrderTotalThisMonth(int returningOrderTotalThisMonth) {
		this.returningOrderTotalThisMonth = returningOrderTotalThisMonth;
	}
	public int getNewOrdersLastMonth() {
		return newOrdersLastMonth;
	}
	public void setNewOrdersLastMonth(int newOrdersLastMonth) {
		this.newOrdersLastMonth = newOrdersLastMonth;
	}
	public int getNewOrdersTotalLastMonth() {
		return newOrdersTotalLastMonth;
	}
	public void setNewOrdersTotalLastMonth(int newOrdersTotalLastMonth) {
		this.newOrdersTotalLastMonth = newOrdersTotalLastMonth;
	}
	public int getReturningOrdersLastMonth() {
		return returningOrdersLastMonth;
	}
	public void setReturningOrdersLastMonth(int returningOrdersLastMonth) {
		this.returningOrdersLastMonth = returningOrdersLastMonth;
	}
	public int getReturningOrderTotalLastMonth() {
		return returningOrderTotalLastMonth;
	}
	public void setReturningOrderTotalLastMonth(int returningOrderTotalLastMonth) {
		this.returningOrderTotalLastMonth = returningOrderTotalLastMonth;
	}
    
    
    
}
