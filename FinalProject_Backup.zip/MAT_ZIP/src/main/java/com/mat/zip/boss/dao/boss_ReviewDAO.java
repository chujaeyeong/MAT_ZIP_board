package com.mat.zip.boss.dao;

import java.util.List;

public interface boss_ReviewDAO {
	List<String> TotalReview(String storeId);
}
