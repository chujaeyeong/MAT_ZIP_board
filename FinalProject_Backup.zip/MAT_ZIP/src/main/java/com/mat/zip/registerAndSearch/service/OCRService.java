package com.mat.zip.registerAndSearch.service;

import java.util.List;

public interface OCRService {
	public List<String> clovaOCR(String savedFilePath);
}
