package com.mat.zip.boss.model;

import java.util.Date;

public class ChartVO {

	private String date;
    private int total_amount;
    private String order_id;
    
    // getters and setters
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

    }
