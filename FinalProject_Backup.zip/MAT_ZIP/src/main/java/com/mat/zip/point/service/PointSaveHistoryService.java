package com.mat.zip.point.service;

import com.mat.zip.point.model.PointSaveHistoryVO;

public interface PointSaveHistoryService {
	void addPoint(PointSaveHistoryVO bag2);
}
